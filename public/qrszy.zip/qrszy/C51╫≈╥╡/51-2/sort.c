#include <reg51.h>

void main(void) {
  unsigned char i, j, temp;
  unsigned char mydata[15] = {27, 5,32,47,38,235,79,17,187,58,23,35,211,104,9};
  for (i = 0; i < 15; i++) {
    for (j = i + 1; j < 15; j++) {
      if (mydata[i] > mydata[j]) {
        temp = mydata[i];
        mydata[i] = mydata[j];
        mydata[j] = temp;
      }
    }
  }
}