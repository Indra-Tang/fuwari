% 定义目标函数，实际求解时 fmincon 寻求最小值，所以目标函数取负值
objective = @(x) -(3*x(1) - (x(1)-1)^2 + 3*x(2) - (x(2)-2)^2);

% 初始猜测
x0 = [0, 0];

% 调用 fmincon 求解
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');
[x_opt, fval] = fmincon(objective, x0, [], [], [], [], [], [], @constraints, options);

% 输出结果
disp(['Optimal solution: x1 = ', num2str(x_opt(1)), ', x2 = ', num2str(x_opt(2))]);
disp(['Maximum objective value: ', num2str(-fval)]);

% 非线性约束函数
function [c, ceq] = constraints(x)
    c = [4*x(1) + x(2) - 20;  % 4*x(1) + x(2) <= 20
         x(1) + 4*x(2) - 20]; % x(1) + 4*x(2) <= 20
    ceq = [];
end
