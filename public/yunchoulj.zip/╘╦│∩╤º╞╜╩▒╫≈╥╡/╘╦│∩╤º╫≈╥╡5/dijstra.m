graph =  [ 0 1 2 inf inf inf;
            1 0 3 3 inf 7;
            2 3 0 2 2 inf;
            inf 3 2 0 inf 3;
          inf inf 2 inf 0 6
            inf 7 inf 3 6 0];
source = 1;
[distance, path] = dijkstra(graph, source);
disp(distance);
disp(path);

function [distance, path] = dijkstra(graph, source)

n = size(graph, 1); % 节点数量
distance = inf(1, n); % 初始化距离向量
distance(source) = 0; % 源节点的距离为 0
path = zeros(n, n); % 初始化路径矩阵

visited = false(1, n); % 初始化已访问节点向量

for i = 1:n
    % 找到距离最小的未访问节点
    [min_distance, min_index] = min(distance(~visited));
    current_node = find(~visited, 1, 'first') + min_index - 1;

    visited(current_node) = true; % 标记当前节点为已访问

    % 更新相邻节点的距离和路径
    for neighbor = 1:n
        if graph(current_node, neighbor) ~= inf && ~visited(neighbor)
            if distance(current_node) + graph(current_node, neighbor) < distance(neighbor)
                distance(neighbor) = distance(current_node) + graph(current_node, neighbor);
                path(neighbor, current_node) = 1; % 记录路径
            end
        end
    end
end
end