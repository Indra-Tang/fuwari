function [x,z]=branch_and_bound_ip(A,b,Cn,Aeq,beq,lb,ub,fcheck)
%A:系数矩阵  
%b:右端常数   
%Cn:目标函数的系数   
%lb:决策变量下界  ub:决策变量上界
%fcheck:目标函数最大值问题,-1;目标函数最小值问题,1;

[m,n]=size(Cn);
Cn=Cn*(-1*fcheck);
[x1,fval,exitflag]=linprog(Cn,A,b,Aeq,beq,lb,ub)  %linprog求解的是最小化问题
for i=1:m
   if (floor(x1(i)) - x1(i) ~= 0)  %判断最优解是否为整数，取出非整数部分
      got = i;
      break;
   end
end

LP1_bound=zeros(m,2);
LP2_bound=zeros(m,2);
LP1_bound(:,2)=inf; 
LP2_bound(:,2)=inf;
x_bound_low=floor(x1(got));
x_bound_up=x_bound_low+1;  
if x_bound_low < LP1_bound(got,2)   
    LP1_bound(got,2)=x_bound_low;
end
if x_bound_up > LP2_bound(got,1)
    LP2_bound(got,1)=x_bound_up;
end

[x_LP1,f1,exitflag1] = linprog(Cn,A,b,Aeq,beq,LP1_bound(:,1),LP1_bound(:,2));
[x_LP2,f2,exitflag2] = linprog(Cn,A,b,Aeq,beq,LP2_bound(:,1),LP2_bound(:,2));
exitf=[exitflag1,exitflag2]; 
table=zeros(2,m+1); 
f_bound=zeros(1,2); 
f_bound(1)=-inf;

while 1
    j=find(exitf<0);
    if (j==1)
        LP1_bound=LP2_bound;  
        x_LP1=zeros(m);    
        f1=inf;
    elseif (j==2)
        LP2_bound=LP1_bound;   
        x_LP2=[0;0];   
        f2=inf;
    end
    for i=1:m
        table(1,i)=x_LP1(i);
        table(2,i)=x_LP2(i);
    end
    table(1,m+1)=-fcheck*f1;
    table(2,m+1)=-fcheck*f2;
    f_bound(2)=-inf;
    for i=1:2
        if table(i,3)>f_bound(2)
            f_bound(2)=table(i,3);
        end
        if (max(abs(round(table(i,1:m))-table(i,1:m)))<=1e-10)
            if table(i,3)>f_bound(1)
                f_bound(1)=table(i,3);
            end
        end
    end
    if (f_bound(1)==f_bound(2))
        disp("最优解为:")
        if table(1,3)==f_bound(1)
            x=x_LP1;
        end
        if table(2,3)==f_bound(1)
            x=x_LP2;
        end
        disp("目标函数最优取值为:")
        z=f_bound(1);
        break;
    end
    [max_f,ind]=max(table(:,3)); 
    for i=1:m
        if (rem(table(ind,i),1)~=0)
            got=i;
            break;
        end
    end
    x_bound_low=floor(table(ind,got));
    x_bound_up=x_bound_low+1;  
    
     if (ind == 1)
        LP2_bound=LP1_bound;  
    end
    if  (ind == 2) 
        LP1_bound=LP2_bound;     
    end
    if (x_bound_low < LP1_bound(got,2))
        LP1_bound(got,2)=x_bound_low;
    end
    if (x_bound_up > LP2_bound(got,1))
        LP2_bound(got,1)=x_bound_up;
    end
    [x_LP1,f1,exitflag1]=linprog(Cn,A,b,Aeq,beq,LP1_bound(:,1),LP1_bound(:,2));
    [x_LP2,f2,exitflag2]=linprog(Cn,A,b,Aeq,beq,LP2_bound(:,1),LP2_bound(:,2));
    exitf=[exitflag1,exitflag2];
end

end