ts=[0,30];
y0=[1;0];
[tt,yy]=ode45(@ex11_3_fun,ts,y0);
plot(tt,yy)
grid