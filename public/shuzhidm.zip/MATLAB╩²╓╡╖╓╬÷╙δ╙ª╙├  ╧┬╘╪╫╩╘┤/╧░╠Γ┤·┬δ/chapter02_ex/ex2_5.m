%ϰ��2-5
syms x y 

z=sin(x*y);

d_2y_x=diff(diff(diff(z,y),y),x)