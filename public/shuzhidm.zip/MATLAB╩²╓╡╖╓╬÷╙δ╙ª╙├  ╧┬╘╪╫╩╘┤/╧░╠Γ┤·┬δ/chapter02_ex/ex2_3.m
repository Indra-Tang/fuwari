%ϰ��2-3
syms x
f=(1-x)/(1+x);
tay_f=taylor(f,6)