%%ϰ��2-1

syms x
f=log(1+1/x)/acot(x);
limit(f,inf)
