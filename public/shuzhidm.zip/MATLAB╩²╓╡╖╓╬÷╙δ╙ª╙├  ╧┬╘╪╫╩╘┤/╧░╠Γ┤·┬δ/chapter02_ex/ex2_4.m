%ϰ��2-4
syms t
y=t*sin(t);
s=int(y,0,pi)