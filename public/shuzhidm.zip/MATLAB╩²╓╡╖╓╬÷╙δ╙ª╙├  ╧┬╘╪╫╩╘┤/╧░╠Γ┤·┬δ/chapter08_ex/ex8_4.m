%ϰ��8-4����
%John H.Mathews  P185
format short
k=0:3;
x=cos(pi*(2*k+1)/8);
c0=exp(x).*cos(0*x);
c0=sum(c0)/4;   %ϵ��c0


c1=exp(x).*cos(1*acos(x));
c1=sum(c1)/2;

c2=exp(x).*cos(2*acos(x));
c2=sum(c2)/2;

c3=exp(x).*cos(3*acos(x));
c3=sum(c3)/2;

c=[c0 c1 c2 c3]