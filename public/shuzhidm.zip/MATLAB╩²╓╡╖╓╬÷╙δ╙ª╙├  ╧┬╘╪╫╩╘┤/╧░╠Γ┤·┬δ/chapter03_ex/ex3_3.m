%ϰ��3-3
syms a t
syms p positive
f=1/(t^2+p^2);
F=fourier(f)