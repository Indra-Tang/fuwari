syms w a
f=-i*w/(a^2+w^2)/pi;
ifourier(f)