%ϰ��3-6
syms s a 
f=1/s/(s^2+a^2);
ilaplace(f)