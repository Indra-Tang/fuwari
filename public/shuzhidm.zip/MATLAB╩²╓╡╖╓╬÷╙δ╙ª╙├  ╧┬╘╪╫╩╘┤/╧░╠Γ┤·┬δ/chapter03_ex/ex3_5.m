%ϰ��3-5
syms a t
f=1/a^2*t-1/a^3*sin(a*t)
laplace(f)