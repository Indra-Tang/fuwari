function f=df2(x0)
x=x0(1);
y=x0(2);
z=x0(3);
f=[3 z*sin(x*y) y*sin(y*z)
2*x -162*(y+0.1) cos(z)
-y*exp(-x*y) -x*exp(-x*y) 20];