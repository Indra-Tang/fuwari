function F = myfun(A)
F = A^3-A^2-[5 6;7,8];