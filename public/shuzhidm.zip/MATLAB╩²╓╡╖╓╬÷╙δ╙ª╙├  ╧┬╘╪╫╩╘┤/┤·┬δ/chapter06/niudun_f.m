function f=niudun_f(x)
a=x(1)-0.7*sin(x(1))-0.2*cos(x(2));
b=x(2)-0.7*cos(x(1))+0.2*sin(x(2));

f=[a b];