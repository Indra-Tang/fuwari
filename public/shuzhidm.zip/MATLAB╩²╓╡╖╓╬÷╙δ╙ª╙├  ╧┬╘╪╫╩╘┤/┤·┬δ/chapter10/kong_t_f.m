function f=kong_t_f(x)
f=exp(-x^2);