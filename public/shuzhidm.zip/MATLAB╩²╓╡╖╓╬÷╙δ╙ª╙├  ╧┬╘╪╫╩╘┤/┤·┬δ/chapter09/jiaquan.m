H=[1 0;0 1];

R=[1 0;0 5];
P=inv(H'*H)*R*H*inv(H'*H)