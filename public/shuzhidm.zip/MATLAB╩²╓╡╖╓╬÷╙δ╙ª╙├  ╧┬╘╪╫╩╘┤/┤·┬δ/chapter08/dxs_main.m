%Legendre�� Laguerre��Hermite����ʽ������
%Legendre ����ʽ
syms x
T1=leg_p(x,5);
disp('Legendre����ʽΪ')
for i=1:6
disp(T1(i))
end

v=[-1,1,-1,1];
subplot(3,2,1),ezplot(T1(1)),axis([-1,1,-0.5,1.5]),grid
subplot(3,2,2),ezplot(T1(2)),axis(v),grid
subplot(3,2,3),ezplot(T1(3)),axis(v),grid
subplot(3,2,4),ezplot(T1(4)),axis(v),grid
subplot(3,2,5),ezplot(T1(5)),axis(v),grid
subplot(3,2,6),ezplot(T1(6)),axis(v),grid
%Laguerre����ʽ
disp('Laguerre����ʽΪ')
T2=lague_p(x,5);
for i=1:6
disp(T2(i))
end
figure(2)

subplot(3,2,1),ezplot(T2(1)),axis([-1,1,-0.5,1.5]),grid
subplot(3,2,2),ezplot(T2(2)),grid
subplot(3,2,3),ezplot(T2(3)),grid
subplot(3,2,4),ezplot(T2(4)),grid
subplot(3,2,5),ezplot(T2(5)),grid
subplot(3,2,6),ezplot(T2(6)),grid
%Hermite����ʽ
disp('Hermite����ʽΪ')
T3=herm_p(x,5);
for i=1:6
disp(T3(i))
end
figure(3)

subplot(3,2,1),ezplot(T3(1)),axis([-1,1,-0.5,1.5]),grid
subplot(3,2,2),ezplot(T3(2)),grid
subplot(3,2,3),ezplot(T3(3)),grid
subplot(3,2,4),ezplot(T3(4)),axis([-2,2,-20,20]),grid
subplot(3,2,5),ezplot(T3(5)),axis([-2,2,-20,20]),grid
subplot(3,2,6),ezplot(T3(6)),axis([-2,2,-100,100]),grid