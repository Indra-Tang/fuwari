[xc,num,eps] = budongdian(@g,0.8)
x=0:0.01:1;
y=x.^3+x-1;
plot(x,y)
grid on
