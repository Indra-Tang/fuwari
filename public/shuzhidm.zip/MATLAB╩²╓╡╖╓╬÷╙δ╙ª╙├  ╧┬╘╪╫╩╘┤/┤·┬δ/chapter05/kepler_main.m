
[E,n]=kepler_Newton(0.01,32,1e-14)