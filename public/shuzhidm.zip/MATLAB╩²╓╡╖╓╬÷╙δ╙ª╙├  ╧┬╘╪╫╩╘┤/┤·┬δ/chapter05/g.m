
function y = g(x)
y = nthroot(1-x,3);