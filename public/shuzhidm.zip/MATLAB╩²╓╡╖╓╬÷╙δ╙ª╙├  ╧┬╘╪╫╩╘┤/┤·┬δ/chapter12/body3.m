function body3
%ORBITODE  Restricted three body problem.

mu = 1 / 82.45;


tspan = [0 100];


% y0a= [-1/2+mu; sqrt(3)/2; 0; 0];
% [t,ya] = ode45(@f,tspan,y0a);
% ya=ya/100;
% plot(ya(:,1),ya(:,2))
% grid


delt=1200/384401;
y0b=[-1/2+mu+delt; sqrt(3)/2+delt; 0; 0];
[t,yb] = ode45(@f,tspan,y0b);
%yb=yb/100;
plot(yb(:,1),yb(:,2))
grid








% --------------------------------------------------------------------------

function dydt = f(t,y)
mu = 1 / 82.45;
mustar = 1 - mu;
r13 = ((y(1) + mu)^2 + y(2)^2) ^ 1.5;
r23 = ((y(1) - mustar)^2 + y(2)^2) ^ 1.5;
dydt = [ y(3)
         y(4)
         2*y(4) + y(1) - mustar*((y(1)+mu)/r13) - mu*((y(1)-mustar)/r23)
         -2*y(3) + y(2) - mustar*(y(2)/r13) - mu*(y(2)/r23) ];



