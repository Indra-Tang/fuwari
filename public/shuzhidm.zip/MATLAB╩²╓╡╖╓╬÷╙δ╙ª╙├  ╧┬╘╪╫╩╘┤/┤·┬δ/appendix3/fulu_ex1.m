function s=lianjia(n)
s=0;
for i=1:n
    s=s+i;
end