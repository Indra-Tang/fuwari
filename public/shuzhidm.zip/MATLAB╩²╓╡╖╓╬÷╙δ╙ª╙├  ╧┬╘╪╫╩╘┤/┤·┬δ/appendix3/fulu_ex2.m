function f=fulu_ex2(x)
f=x.^2+x.*cos(x);