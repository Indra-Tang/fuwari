n=20;
x=2;
f=fulu_ex3(x,n)