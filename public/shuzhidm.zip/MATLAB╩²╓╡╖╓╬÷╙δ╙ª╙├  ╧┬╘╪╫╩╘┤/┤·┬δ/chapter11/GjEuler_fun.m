function f=GjEuler_fun(t,x)
f=1/t*(x^2+x);