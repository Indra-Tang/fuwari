function f=Euler_fun(t,x)
f=2/t*x+t^2*exp(t);

